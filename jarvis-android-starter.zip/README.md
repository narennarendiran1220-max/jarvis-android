# JARVIS Android starter

A beginner-friendly Android starter app with:
- English/Tamil greeting and a few built-in offline-style commands
- Tap-to-talk using Android's installed speech recognition service
- Spoken replies using Android Text-to-Speech
- GitHub Actions workflow to build a debug APK in the cloud

## Important limitations in this first version
- This is a **tap-to-talk starter**, not an always-listening "Hey JARVIS" app.
- Speech recognition may use Google's service and may require internet, depending on the phone and installed speech engine.
- Text-to-Speech language availability depends on voices installed on the phone.
- No online AI API is connected yet. Never put API keys directly in source code or commit them to GitHub.

## Build
GitHub Actions builds `app-debug.apk` whenever you push to `main`, or when you manually run the workflow.
Open the repository's **Actions** tab, select **Build JARVIS Android APK**, open the latest successful run, and download the `jarvis-debug-apk` artifact.

## Install
On Android, download and extract the artifact ZIP, tap `app-debug.apk`, and allow installation from that source if Android asks. Only install APKs you built or trust.

## Next development stages
1. Test microphone permission and speech on your phone.
2. Add a real wake-word engine for "Hey JARVIS" (requires a wake-word model and access key; keep credentials private).
3. Add online AI through a small backend so the API key is not stored in the APK.
4. Add a foreground microphone service and battery-optimization guidance if always-on wake word is implemented.
