package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Typeface
import android.graphics.Color
import android.util.TypedValue
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var reply: TextView
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private val requestAudio = 101
    private val requestSpeech = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(8, 18, 32))
        }

        val heading = TextView(this).apply {
            text = "J.A.R.V.I.S"
            setTextColor(Color.rgb(0, 220, 255))
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Your assistant is ready"
            setTextColor(Color.WHITE)
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 18)
        }
        reply = TextView(this).apply {
            text = "Tap the button and speak in English or Tamil."
            setTextColor(Color.LTGRAY)
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        val talk = Button(this).apply {
            text = "🎙  TALK TO JARVIS"
            textSize = 18f
            setOnClickListener { startListening() }
        }
        val test = Button(this).apply {
            text = "Test voice"
            setOnClickListener { speak("Hello. I am JARVIS. வணக்கம். நான் ஜார்விஸ்.") }
        }
        layout.addView(heading)
        layout.addView(status)
        layout.addView(reply)
        layout.addView(talk)
        layout.addView(test)
        setContentView(layout)
    }

    override fun onInit(result: Int) {
        ttsReady = result == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts.language = Locale("en", "IN")
            tts.setSpeechRate(0.95f)
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS / ஜார்விஸிடம் பேசுங்கள்")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            startActivityForResult(intent, requestSpeech)
            status.text = "Listening…"
        } catch (_: Exception) {
            status.text = "Speech recognition is unavailable on this phone."
            reply.text = "Enable a speech recognition service, such as Google voice typing."
        }
    }

    @Deprecated("Uses Android's speech recognition activity for this starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestSpeech && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val heard = words?.firstOrNull().orEmpty()
            reply.text = "You said: $heard"
            respondTo(heard)
        }
    }

    private fun respondTo(input: String) {
        val q = input.lowercase(Locale.ROOT)
        val answer = when {
            q.contains("hello") || q.contains("hi") || q.contains("வணக்கம்") ->
                "Hello! I am JARVIS. How can I help you? / வணக்கம்! நான் எப்படி உதவலாம்?"
            q.contains("time") || q.contains("நேரம்") ->
                "The time is " + java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())
            q.contains("date") || q.contains("தேதி") ->
                "Today is " + java.text.SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(java.util.Date())
            q.contains("your name") || q.contains("உன் பெயர்") ->
                "I am JARVIS, your personal assistant."
            q.contains("thank") || q.contains("நன்றி") ->
                "You're welcome! / மகிழ்ச்சி!"
            else ->
                "I heard: $input. Online AI answers and custom commands can be added in the next stage."
        }
        reply.text = answer
        speak(answer)
    }

    private fun speak(message: String) {
        if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
